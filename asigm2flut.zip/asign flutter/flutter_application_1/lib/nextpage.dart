import 'package:flutter/material.dart';

class nextpage extends StatelessWidget {
  const nextpage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Padding(
        padding: const EdgeInsets.all(50),
        child: Center(
          child: Column(children: [
            CircleAvatar(radius: 150,
            backgroundImage:AssetImage("images/p1.jpg") ,
            ),
              
             Text("Aisha Abshir",style: TextStyle(fontSize: 40),),
             ElevatedButton(onPressed: (){
              Navigator.pop(context);
             },
              child: Text("Back"))

    ]),
        ),),
    );
  }
}