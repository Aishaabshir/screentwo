import 'package:flutter/material.dart';
import 'package:flutter_application_1/nextpage.dart';

class home extends StatelessWidget {
  const home({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Center(child: Text("Welcome my profile")),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Center(
          child: Column(children: [
            CircleAvatar(radius: 150,
            backgroundImage:AssetImage("images/p1.jpg") ,
            ),
              
             Text("Aisha Abshir",style: TextStyle(fontSize: 40),),
             ElevatedButton(onPressed: (){
              Navigator.push(context, MaterialPageRoute(builder: (context)=>const nextpage()));



             }, 
             child: Text("next screen"))
            
            


          ]),
        ),
      ),
      


    );
  }
}